marks=input('Enter your marks: ');
if(marks>100||marks<0)
    disp('Inavlid marks')
elseif marks>=80
    disp('A+')
elseif marks>=75
    disp('A')
elseif marks>=70
    disp('A-')
elseif marks>=65
    disp('B+')
elseif marks>=60
    disp('B')
elseif marks>=55
    disp('B-')
elseif marks>=50
    disp('C+')
elseif marks>=45
    disp('C')
elseif marks>=40
    disp('C-')
elseif marks>=35
    disp('D+')
elseif marks>=30
    disp('D')
else
    disp('E')
end





