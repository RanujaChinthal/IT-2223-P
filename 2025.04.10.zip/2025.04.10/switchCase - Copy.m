day = input('Enter the current day (1-5): ');

switch (day)
    case 1
        disp('Monday')
    case 2
        disp('Tuesday')
    case 3
        disp('Wednesday')
    case 4
        disp('Thursday')
    case 5
        disp('Friday')
    otherwise
        disp('inavlid day')
end
