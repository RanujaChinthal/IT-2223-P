gpa = zeros(1,5);
marks = zeros(1,5);

for i=1:5
    marks(i)=input(['Enter marks for subject : ',i]);

        
   if marks(i)>=80 && marks(i)<=100
        disp('A+');
        gpa(i)=4.0;
    elseif marks(i)>=75
        disp('A')
        gpa(i)=4.0;
    elseif marks(i)>=70
        disp('A-')
        gpa(i)=3.7;
    elseif marks(i)>=65
        disp('B+')
        gpa(i)=3.3;
    elseif marks(i)>=60
        disp('B')
        gpa(i)=3.0;
    elseif marks(i)>=55
        disp('B-')
        gpa(i)=2.7;
    elseif marks(i)>=50
        disp('C+')
        gpa(i)=2.3;
    elseif marks(i)>=45
        disp('C')
        gpa(i)=2.0;
    elseif marks(i)>=40
        disp('C-')
        gpa(i)=1.7;
    elseif marks(i)>=35
        disp('D+')
        gpa(i)=1.3;
    elseif marks(i)>=30
        disp('D')
        gpa(i)=1.0;
    else
        disp('E')
        gpa(i)=0.0;
    end
end


    GPA = mean(gpa);
    fprintf('\n Your GPA is : %.2f\n',GPA);
