%int type user input
x = input('Enter the number : ');
disp(['You entered ',num2str(x)]);

%string type user input
y = input('Enter your name : ','s');
disp(['Your name is ',y]);