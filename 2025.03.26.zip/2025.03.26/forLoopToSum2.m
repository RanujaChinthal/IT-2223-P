%write a for loop to calculate the sum of the numbers from 1-10

f = 1;
for i = 1:5
    f=f+i;
end
disp(f)


