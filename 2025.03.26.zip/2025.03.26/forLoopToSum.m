%write a for loop to calculate the sum of the numbers from 1-10

sum = 0;
for i = 1:10
    sum=sum+i;
end
disp(sum)


