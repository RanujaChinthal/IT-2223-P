%how to print a sring and int together

x=10;
disp(['The number is : ',num2str(x)])
disp("The number is : "+x)
fprintf('The number is : %d',x)
y=sprintf('The number is : %d',x)
disp(y)