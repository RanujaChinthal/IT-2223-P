num = 5

if mod(num,2) == 1
    disp ('ODD')
else
    disp('EVEN')
end


