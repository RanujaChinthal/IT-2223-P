num = 4;
if num>0
    disp('Number is Positive')
else
    disp('Number is Negative')
end
